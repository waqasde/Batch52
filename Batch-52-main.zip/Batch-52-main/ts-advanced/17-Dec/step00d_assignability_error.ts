let message = "Hello World";
//message = 6; //error
console.log(message);
export {};
