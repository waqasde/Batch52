"use strict";
const b = 10;
const c = 2;
