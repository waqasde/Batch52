export const b3 = 10;

export const c3 = 2;
