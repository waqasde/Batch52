//import always on top
import a3, { a4, a5, a6, a7 } from "./first";
import { b3, c3 } from "./second";

console.log(a3);
console.log(b3);
console.log(c3);
console.log(a4);
console.log(a5);
console.log(a6);
console.log(a7);
