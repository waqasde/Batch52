"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let a3 = 5;
let a4 = 5;
let a5 = 5;
let a6 = 5;
exports.default = a3;
//export default a4; // only single default export possible from file
