let a3 = 53;
let a4 = 4;
let a5 = 5;
let a6 = 6;
let a7 = 57;

//object {key:value,key2:value,key3:value}
// array []
// ['a','b','c']

export { a4, a5, a6, a7 };
export default a3;
//export default a4; // only single default export possible from file
