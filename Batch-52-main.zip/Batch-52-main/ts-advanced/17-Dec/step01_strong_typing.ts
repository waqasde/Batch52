//strongly typed syntax
let a: string = "Pakistan";
a = "USA";
let b: number = 9;
let c: boolean = true;

// //type inference
let e = "USA";
let f = 10.9;
f = 22;
let g = false;
g = true;

export {};
