// node install (LTS) 64bit minimum v.18.16.0 // v20.9.0 // v21
// node -v
// typescript globally
// window npm install -g typescript (-g => Global)
// mac/linus sudo npm install -g typescript
// tsc -v minimum 5.3.2
// VS code install

// folder // index.ts
// tsc --init (tsconfig.json)
// console.log("Hello World")
// tsc (compile) => typescript => javascript
// run => node filename.js => node index.js

// VS terminal => powershell => cmd
// terminal => (+:) => select default profile
// command  (CMD) window
// zsh (Mac)

// variables
// Variables rules
// 1 : start with aplh,_$  or _ (underscore)
// 2: variable name can contain aplh number $ _
// 3: special charters not included
// 4: space not allowed
// 5:  numbers are not allowed at the beginning of the varibale name

//comments
// single line
// multiline

// data type
// preemptive  or non-preemptive

// preemptive data Types
// string
// number
// boolean
// null
// undefined ( default value)

// let  change
//const  fix

// typeof (type checking) => type

// non-preemptive
// Array : []
// Objects : {}

// Array Methods
// push , pop , shift , unshift , slice , splice
// push add value end of array
// pop remove value from end
// shift remove value from start
// unshift add value from start
// slice //  return part of an array and create new one
// splice , values add , remove , start, end ,mid

// functions
// Name Functions
// function FunctionName(){}
// parameters
// value return // nope
// Arrow Function
// const sum = ()=>{};

// loops
// for
// for(variable ; condition ; variable++)

// conditional statement
// if else
// if elseif
// nested if else

// Operators
// logical
// assignment oper
// compare
//arithmetics

// Advanced

// npm init -y
// tsc --init
// tsconfig.json changes
// 16: target es2020
// 28 : module : nodeNext
// 30 : moduleRes. : nodeNext
// 58 : './out'

// package.json
// "type":"module"

// let ,const
// npm @node-types
// node_modules  (not open)
// package.lock.json (not open)
// .gitignore (node_modules)

// Syntax Error  // leeet name='ghj'
// Unexpected Token '}' Expected ';'

//Type Error
// Assignability Error  (jb ap kese varibale ko values ghlt assign krty)

// union literals
// let name:string | number

//objects
// let, const
// key : value // key variables
// let student={
//     "name":'Jahanzaib',
//     "age":25
// }

// object_aliased
// let student ={ name:string , age:number}
// let student={name:'Jahanzaib',age:25}

// type , interface
// type typeName={}
// type student ={ name:string,age:number}
// let Student:student={}

// interface  interface name:{name:string,age:number}

//object 5 (structural_typing_object_literals)
// fresh // stale object
// const student={name:'Jahanzaib'} fresh
// let student1=student // stale
// left side ki keys = Right side

// index Signature

// Functions
// function greeting(name: string): void {}
// Arrow Functions
//let greeting=(name:string)=>void{}
// parameters types and return types
// ()=>void
// (a:number,b:number)=>number
// parameters (required)
//greeting=(name:string)=>void{}
// ?parameters (optional)
//greeting=(name?:string)=>void{}
// rest parameter ...parameter []
//greeting=(firstName:string,lastName:string,...fullName:[string])=>void{}
// default parameter
//greeting=(name="John",age=30)=>void{}

// lamda Function
//anonymous function type with optional parameters
// Name Functions // Arrow Functions

// intersection (&)

// Special Types (Any , unknown , never)

// explicit casting

// Array
// let name:string[]
// let name = new Array()
// let name:Array<string>

//Enums
// const
// simple  enum

// import export
// single export
// default export
// multiple exports
// object literal export

//callbacks
// promises
// async await

// tuples

// template  literals

// Assignment 45 Questions
// Node Projects (10)
//  calculator (publish)  // inquire.js
// 10 => 4
// 7 Jan Students (2)  (4th Feb)
// quarter break 2 Weeks
