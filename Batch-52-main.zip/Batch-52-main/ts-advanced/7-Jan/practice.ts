function powerFunction(x: number, y: number, z: number) {
  let a = x ** y;
  return a ** z;
}
type name = {
  firstName: string;
  lastName: string;
  email: string;
};
let umt: name = {
  firstName: "junaid",
  lastName: "hussain",
  email: "",
};

let box: number | string | boolean;
box = 10;
