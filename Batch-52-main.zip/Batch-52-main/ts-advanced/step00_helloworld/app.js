"use strict";
console.log("Hello i am node project");
