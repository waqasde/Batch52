console.log("Hello i am ts file ok good one");

let firstName = "Jahanzaib";
const lastName = "Tayyab";

console.log(firstName);

console.log(lastName);

//Variables Rules

//1 can't contain any spaces
//let name ggg='GHH'
let space = 1234;

// 2 variable can contain only numbers , letters , _ ,$

let v1 = "23";
let vvv = "2";
let vv_2 = 45;
let gg$ = 677;

//let fg@=566
//let fg!='rtt'

// 3 variable name can't start with number

//let 34hhh=56

let g = 55;
let _f = 55;
let $g = 566;
let f123 = "frgggg";
