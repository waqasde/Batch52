"use strict";
console.log("Hello i am ts file ok good one");
let firstName = "Jahanzaib";
let lastName = "Tayyab";
console.log(firstName);
console.log(lastName);
