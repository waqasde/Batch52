function SettingPage() {
  return <div>SettingPage</div>;
}

export default SettingPage;
