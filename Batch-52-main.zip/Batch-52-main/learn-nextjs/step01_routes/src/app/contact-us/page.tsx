const ContactUs = () => {
  return <div>This is Contact Us Page</div>;
};

export default ContactUs;
