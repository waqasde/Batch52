function BlogPage() {
  return <div>This is my Blog Page</div>;
}

export default BlogPage;
