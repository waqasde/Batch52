import React from "react";

function Footer() {
  return (
    <div className="bg-gray-500 justify-center flex p-3 mt-5">All is well</div>
  );
}

export default Footer;
