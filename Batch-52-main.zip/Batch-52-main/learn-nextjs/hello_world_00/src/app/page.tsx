function HomePage() {
  return <div>Hello World 2 This is Update This is auto</div>;
}

export default HomePage;
